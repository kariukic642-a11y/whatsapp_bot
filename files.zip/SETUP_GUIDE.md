# WhatsApp AI Bot — Setup Guide

## What You're Building
A WhatsApp bot that:
- Replies automatically using Claude AI
- Remembers conversation context per user
- Runs 24/7 for free on Railway

---

## Step 1: Get Your API Keys

### Anthropic API Key (Claude)
1. Go to: https://console.anthropic.com
2. Sign up / log in
3. Click "API Keys" → "Create Key"
4. Copy and save the key (starts with sk-ant-)

### Twilio Account (WhatsApp Gateway)
1. Go to: https://www.twilio.com/try-twilio
2. Sign up for a FREE trial account
3. Verify your phone number
4. Go to Console → Messaging → Try WhatsApp
5. Follow the sandbox instructions:
   - Send the join code to +1 415 523 8886 on WhatsApp
   - Example: "join bright-eagle" (your code will differ)
6. Save your:
   - Account SID
   - Auth Token
   - Sandbox number

---

## Step 2: Deploy to Railway (Free Hosting)

1. Go to: https://railway.app
2. Sign up with GitHub (recommended)
3. Click "New Project" → "Deploy from GitHub repo"
4. Upload your bot files OR use Railway's file editor
5. Add Environment Variables:
   - Click your project → "Variables"
   - Add: ANTHROPIC_API_KEY = (your key from Step 1)
6. Railway will give you a public URL like:
   https://whatsapp-bot-production.up.railway.app

---

## Step 3: Connect Twilio to Your Bot

1. Go to Twilio Console → Messaging → Settings → WhatsApp Sandbox Settings
2. In "When a message comes in" field, paste:
   https://YOUR-RAILWAY-URL.up.railway.app/webhook
3. Set method to: HTTP POST
4. Click Save

---

## Step 4: Test It!

1. Open WhatsApp
2. Send any message to your Twilio sandbox number
3. Your AI bot replies within seconds!

---

## Customizing Your Bot

Open index.js and edit the SYSTEM_PROMPT variable to change the bot's personality:

Examples:
- Customer service: "You are a helpful customer service agent for [Your Business]. Answer questions about our products..."
- Personal assistant: "You are my personal assistant. Help me manage tasks, answer questions, and be proactive..."
- Language tutor: "You are a friendly language tutor. Help the user practice [language]..."

---

## Privacy Features

### Hide Read Receipts (Incognito Mode)
Since this bot runs separately from your personal WhatsApp, your personal read receipts are unaffected.

For your personal number:
- WhatsApp → Settings → Privacy → Read Receipts → OFF

### Auto-reply When Busy
The bot handles messages automatically, so you only respond when you choose to.

---

## Troubleshooting

Bot not replying?
- Check Railway logs for errors
- Make sure the webhook URL in Twilio is correct
- Verify your Anthropic API key is set in Railway variables

Getting "join" errors?
- Make sure you sent the join code to the Twilio sandbox number first

---

## Going Live (Optional Upgrade)

The free Twilio sandbox works only for numbers that have joined.
To message anyone, apply for WhatsApp Business API access at:
https://www.twilio.com/whatsapp/request-access
